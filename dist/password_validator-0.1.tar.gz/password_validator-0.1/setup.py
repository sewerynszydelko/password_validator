from setuptools import setup

setup(
    name='password_validator',
    version='0.1',
    description='Colletion of password validators',
    packages=['password_validator'],
    install_requires=['requests']
)
